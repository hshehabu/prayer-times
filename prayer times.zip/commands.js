const commands = [
    {command :"/prayertime" , description : "look for any prayer time at any city"},
]
module.exports = commands